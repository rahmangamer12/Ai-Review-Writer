// Content Script - Scrapes reviews from supported platforms

console.log('[AutoReview AI] Content script loaded');

// Platform detection
const PLATFORM = detectPlatform();

function detectPlatform() {
  const url = window.location.href;
  if (url.includes('google.com/maps') || url.includes('business.google')) return 'google';
  if (url.includes('facebook.com')) return 'facebook';
  if (url.includes('yelp.com')) return 'yelp';
  if (url.includes('tripadvisor.com')) return 'tripadvisor';
  if (url.includes('trustpilot.com')) return 'trustpilot';
  return 'unknown';
}

function createElement(tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text !== undefined) element.textContent = text;
  return element;
}

// Scrape reviews based on platform
function scrapeReviews() {
  const reviews = [];

  switch (PLATFORM) {
    case 'google':
      reviews.push(...scrapeGoogleReviews());
      break;
    case 'facebook':
      reviews.push(...scrapeFacebookReviews());
      break;
    case 'yelp':
      reviews.push(...scrapeYelpReviews());
      break;
    case 'tripadvisor':
      reviews.push(...scrapeTripAdvisorReviews());
      break;
    case 'trustpilot':
      reviews.push(...scrapeTrustpilotReviews());
      break;
  }

  return reviews;
}

// Google Maps/Business Reviews - IMPROVED SELECTORS
function scrapeGoogleReviews() {
  const reviews = [];

  // Try multiple selectors for review containers
  let reviewElements = document.querySelectorAll('[data-review-id]');

  // Fallback: look for review-like containers
  if (reviewElements.length === 0) {
    reviewElements = document.querySelectorAll('.wiI7pd, [class*="review-text"], [class*="review-body"]');
  }

  reviewElements.forEach((el, index) => {
    try {
      // Get text - try multiple selectors
      let text = '';
      const textSelectors = [
        '[class*="wiI7pd"]',
        '[class*="review-text"]',
        '[class*="review-body"]',
        '.Gveq4b', // Google Maps review text class
        '[data-review-text]'
      ];

      for (const selector of textSelectors) {
        const textEl = el.querySelector(selector);
        if (textEl) {
          text = textEl.textContent?.trim() || '';
          if (text) break;
        }
      }

      // If no text found, try the element itself
      if (!text && el.textContent) {
        text = el.textContent.trim();
      }

      if (!text || text.length < 5) return; // Skip empty/short text

      // Get author
      let author = 'Customer';
      const authorSelectors = ['.d4r55', '[class*="author"]', '[class*="y"]', '[data-author]'];
      for (const selector of authorSelectors) {
        const authorEl = el.querySelector(selector);
        if (authorEl) {
          author = authorEl.textContent?.trim() || 'Customer';
          if (author && author !== 'Customer') break;
        }
      }

      // Get rating
      let rating = 5;
      const ratingSelectors = ['[class*="kvMYJc"]', '[role="img"][aria-label*="star"]', '[aria-label*="star"]'];
      for (const selector of ratingSelectors) {
        const ratingEl = el.querySelector(selector);
        if (ratingEl) {
          const ariaLabel = ratingEl.getAttribute('aria-label') || '';
          const match = ariaLabel.match(/(\d)/);
          if (match) {
            rating = parseInt(match[1]);
            break;
          }
        }
      }

      reviews.push({
        id: `google_${index}`,
        author,
        rating,
        text,
        date: '',
        platform: 'google',
        element: el,
      });
    } catch (e) {
      // Skip errors
    }
  });

  return reviews;
}

// Facebook Reviews
function scrapeFacebookReviews() {
  const reviews = [];
  const reviewElements = document.querySelectorAll('[role="article"]');

  reviewElements.forEach((el, index) => {
    try {
      const author = el.querySelector('h3 a, strong, [role="link"]')?.textContent?.trim() || 'Anonymous';
      const text = el.querySelector('[dir="auto"]')?.textContent?.trim() || '';

      if (text && text.length > 10) {
        reviews.push({
          id: `facebook_${index}`,
          author,
          rating: 5, // Facebook doesn't always show ratings
          text,
          date: '',
          platform: 'facebook',
          element: el,
        });
      }
    } catch (e) {
      console.error('Error scraping Facebook review:', e);
    }
  });

  return reviews;
}

// Yelp Reviews
function scrapeYelpReviews() {
  const reviews = [];
  const reviewElements = document.querySelectorAll('.review, [class*="review__"]');

  reviewElements.forEach((el, index) => {
    try {
      const author = el.querySelector('.user-display-name, [class*="user-name"]')?.textContent?.trim() || 'Anonymous';
      const ratingEl = el.querySelector('.i-stars, [class*="star-rating"]');
      const ratingMatch = ratingEl?.className?.match(/i-stars--(\d)-/) || ratingEl?.getAttribute('aria-label')?.match(/(\d)/);
      const rating = ratingMatch ? parseInt(ratingMatch[1]) : 5;
      const text = el.querySelector('.raw__09f24__T4Ezm, [class*="comment"], [class*="review-content"]')?.textContent?.trim() || '';
      const date = el.querySelector('.text-color--subtle, time')?.textContent?.trim() || '';

      if (text) {
        reviews.push({
          id: `yelp_${index}`,
          author,
          rating,
          text,
          date,
          platform: 'yelp',
          element: el,
        });
      }
    } catch (e) {
      console.error('Error scraping Yelp review:', e);
    }
  });

  return reviews;
}

// TripAdvisor Reviews
function scrapeTripAdvisorReviews() {
  const reviews = [];
  const reviewElements = document.querySelectorAll('.review-container, [class*="review-container"]');

  reviewElements.forEach((el, index) => {
    try {
      const author = el.querySelector('.username, .memberOverlayLink, [class*="username"]')?.textContent?.trim() || 'Anonymous';
      const ratingEl = el.querySelector('.ui_bubble_rating, [class*="bubble_"]');
      const ratingClass = ratingEl?.className?.match(/bubble_(\d\d)/);
      const rating = ratingClass ? parseInt(ratingClass[1]) / 10 : 5;
      const text = el.querySelector('.prw_rup .partial_entry, [class*="partial_entry"], [class*="review-text"]')?.textContent?.trim() || '';
      const date = el.querySelector('.ratingDate')?.getAttribute('title') || '';

      if (text) {
        reviews.push({
          id: `tripadvisor_${index}`,
          author,
          rating,
          text,
          date,
          platform: 'tripadvisor',
          element: el,
        });
      }
    } catch (e) {
      console.error('Error scraping TripAdvisor review:', e);
    }
  });

  return reviews;
}

// Trustpilot Reviews
function scrapeTrustpilotReviews() {
  const reviews = [];
  const reviewElements = document.querySelectorAll('[data-review-id], [class*="review-card"]');

  reviewElements.forEach((el, index) => {
    try {
      const author = el.querySelector('[data-consumer-name], [class*="consumer-name"]')?.textContent?.trim() || 'Anonymous';
      const ratingEl = el.querySelector('[data-rating], [class*="star-rating"]');
      const rating = parseInt(ratingEl?.getAttribute('data-rating')) || ratingEl?.getAttribute('alt')?.match(/(\d)/)?.[1] || 5;
      const text = el.querySelector('[data-review-content], [class*="review-content"]')?.textContent?.trim() || '';
      const date = el.querySelector('time')?.textContent?.trim() || '';

      if (text) {
        reviews.push({
          id: `trustpilot_${index}`,
          author,
          rating: parseInt(rating) || 5,
          text,
          date,
          platform: 'trustpilot',
          element: el,
        });
      }
    } catch (e) {
      console.error('Error scraping Trustpilot review:', e);
    }
  });

  return reviews;
}

// Add AI Reply buttons to reviews
function addAIReplyButtons() {
  const reviewContainers = getAllReviewContainers();

  reviewContainers.forEach((container) => {
    if (container.dataset.autoreviewButtonAttached === 'true' || container.querySelector(':scope > .autoreview-ai-btn')) return;

    // Check if container is valid
    const reviewData = getReviewFromContainer(container);
    if (!reviewData.text || reviewData.text.length < 5) return;

    const btn = document.createElement('button');
    btn.className = 'autoreview-ai-btn';
    btn.textContent = 'AI Reply';
    btn.type = 'button';
    btn.setAttribute('aria-label', 'Generate AI reply for this review');

    btn.onclick = async (e) => {
      e.preventDefault();
      e.stopPropagation();

      // RE-SCRAPE FRESH ON CLICK to ensure we have the right review
      const freshData = getReviewFromContainer(container);
      if (!freshData.text || freshData.text.length < 5) return;

      btn.textContent = 'Loading...';
      btn.disabled = true;

      try {
        const reply = await generateAIReply(freshData);
        showReplyModal(freshData, reply);
      } catch (err) {
        console.error('Error:', err);
        alert(`AI Error: ${err.message}. Please try again or check your API quota.`);
      } finally {
        btn.textContent = 'AI Reply';
        btn.disabled = false;
      }
    };

    try {
      // Find a good place to append the button
      const actionsArea = container.querySelector('[role="group"], .m7vYec, ._15_v, .review-footer');
      if (actionsArea) {
        actionsArea.appendChild(btn);
      } else {
        container.appendChild(btn);
      }
      container.dataset.autoreviewButtonAttached = 'true';
    } catch (e) {
      console.log('[AutoReview AI] Could not append button:', e);
    }
  });
}

// Get all unique review containers
function getAllReviewContainers() {
  const containerSet = new Set();

  const selectors = [
    '[data-review-id]',
    '[role="article"]',
    '.review',
    '.review-container'
  ];

  selectors.forEach(selector => {
    document.querySelectorAll(selector).forEach(el => {
      // Platform specific validation
      if (PLATFORM === 'facebook' && !el.querySelector('[dir="auto"]')) return;
      if (PLATFORM === 'google' && !el.hasAttribute('data-review-id')) {
        if (!el.querySelector('.wiI7pd') && !el.className.includes('review')) return;
      }

      const nestedReview = el.parentElement?.closest('[data-review-id], [role="article"], .review, .review-container');
      if (nestedReview && nestedReview !== el) return;
      containerSet.add(el);
    });
  });

  return Array.from(containerSet);
}

// Get review data from container element
function getReviewFromContainer(container) {
  const platform = PLATFORM;
  let author = 'Customer';
  let rating = 5;
  let text = '';

  try {
    if (platform === 'google') {
      author = container.querySelector('.d4r55, [class*="author"]')?.textContent?.trim() || 'Customer';
      const ratingEl = container.querySelector('[class*="kvMYJc"], [role="img"][aria-label*="star"]');
      const ratingText = ratingEl?.getAttribute('aria-label') || '';
      rating = parseInt(ratingText.match(/(\d)/)?.[1]) || 5;
      text = container.querySelector('[class*="wiI7pd"], .Gveq4b')?.textContent?.trim() || '';
    } else if (platform === 'facebook') {
      author = container.querySelector('h3 a, strong')?.textContent?.trim() || 'Customer';
      text = container.querySelector('[dir="auto"]')?.textContent?.trim() || '';
      rating = 5;
    } else if (platform === 'yelp') {
      author = container.querySelector('.user-display-name')?.textContent?.trim() || 'Customer';
      const ratingEl = container.querySelector('.i-stars');
      const ratingMatch = ratingEl?.className?.match(/i-stars--(\d)-/);
      rating = ratingMatch ? parseInt(ratingMatch[1]) : 5;
      text = container.querySelector('.raw__09f24__T4Ezm, [class*="comment"]')?.textContent?.trim() || '';
    } else if (platform === 'tripadvisor') {
      author = container.querySelector('.username, .memberOverlayLink')?.textContent?.trim() || 'Customer';
      const ratingEl = container.querySelector('.ui_bubble_rating');
      const ratingClass = ratingEl?.className?.match(/bubble_(\d\d)/);
      rating = ratingClass ? parseInt(ratingClass[1]) / 10 : 5;
      text = container.querySelector('.prw_rup .partial_entry')?.textContent?.trim() || '';
    } else if (platform === 'trustpilot') {
      author = container.querySelector('[data-consumer-name]')?.textContent?.trim() || 'Customer';
      const ratingEl = container.querySelector('[data-rating]');
      rating = parseInt(ratingEl?.getAttribute('data-rating')) || 5;
      text = container.querySelector('[data-review-content]')?.textContent?.trim() || '';
    }
  } catch (e) {
    console.error('Error getting review data:', e);
  }

  return { author, rating, text, platform };
}

// Generate AI reply through the AutoReview backend.
async function generateAIReply(review, tone = 'friendly') {
  // Try multiple API endpoints for reliability
  const API_URLS = [
    'https://ai-review-writer.vercel.app/api/reviews/generate-reply',
  ];

  const payload = {
    reviewText: review.text,
    rating: review.rating,
    authorName: review.author,
    platform: review.platform || 'google',
    tone: tone,
    language: tone === 'desi' ? 'ur' : 'en',
  };

  // Primary path: route through the background service worker (extension origin,
  // covered by host_permissions — avoids page CORS restrictions).
  try {
    const data = await chrome.runtime.sendMessage({ action: 'generateAIReply', payload });
    if (data?.success && data.reply) {
      if (data.metadata?.used_fallback) {
        console.warn('[AutoReview AI] Backend used fallback. Add/verify AI API key in Vercel for live AI replies.');
      }
      return data.reply;
    }
    if (data && data.error) {
      throw new Error(data.error);
    }
  } catch (error) {
    console.warn('[AutoReview AI] Background AI request failed, trying direct fetch:', error.message);
  }

  // Fallback: direct fetch with a timeout.
  for (const API_URL of API_URLS) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 15000); // 15s timeout

      const response = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        console.warn(`[AutoReview AI] ${API_URL} returned ${response.status}, trying next...`);
        continue;
      }

      const data = await response.json();
      if (data.success && data.reply) {
        return data.reply;
      }
      if (data.success && data.data?.reply) {
        return data.data.reply;
      }
    } catch (error) {
      console.warn(`[AutoReview AI] ${API_URL} failed:`, error.message);
      continue;
    }
  }

  throw new Error('AI server unavailable. Please check your connection and AI API keys.');
}

// Show reply modal (built safely with DOM APIs — no innerHTML)
function showReplyModal(review, reply) {
  const existing = document.getElementById('autoreview-modal');
  if (existing) existing.remove();

  const modal = document.createElement('div');
  modal.id = 'autoreview-modal';
  const previewText = `${review.text.substring(0, 150)}${review.text.length > 150 ? '...' : ''}`;

  const overlay = createElement('div', 'autoreview-modal-overlay');
  const content = createElement('div', 'autoreview-modal-content');
  const header = createElement('div', 'autoreview-modal-header');
  const title = createElement('h3', '', 'AI Generated Reply');
  const closeBtn = createElement('button', 'autoreview-close', 'x');
  closeBtn.type = 'button';

  const body = createElement('div', 'autoreview-modal-body');
  const preview = createElement('div', 'autoreview-review-preview');
  preview.append(
    createElement('strong', '', `Review by ${review.author} (${review.rating} stars)`),
    createElement('p', '', previewText)
  );

  const toneRow = createElement('div');
  toneRow.style.marginBottom = '15px';
  toneRow.style.display = 'flex';
  toneRow.style.alignItems = 'center';
  toneRow.style.gap = '10px';

  const toneLabel = createElement('label', '', 'Tone:');
  toneLabel.style.color = '#a0aec0';
  toneLabel.style.fontSize = '13px';

  const toneSelect = document.createElement('select');
  toneSelect.id = 'autoreview-tone-select';
  toneSelect.style.background = 'rgba(255,255,255,0.1)';
  toneSelect.style.border = '1px solid rgba(255,255,255,0.2)';
  toneSelect.style.color = 'white';
  toneSelect.style.borderRadius = '4px';
  toneSelect.style.padding = '4px 8px';
  toneSelect.style.fontSize = '12px';
  [
    ['friendly', 'Friendly'],
    ['professional', 'Professional'],
    ['apologetic', 'Apologetic'],
    ['enthusiastic', 'Enthusiastic'],
    ['desi', 'Desi Style'],
  ].forEach(([value, label]) => {
    const option = createElement('option', '', label);
    option.value = value;
    toneSelect.appendChild(option);
  });

  const replyBox = createElement('div', 'autoreview-reply-box');
  const textArea = document.createElement('textarea');
  textArea.id = 'autoreview-reply-text';
  textArea.rows = 5;
  textArea.value = reply;
  replyBox.appendChild(textArea);

  const footer = createElement('div', 'autoreview-modal-footer');
  const regenBtn = createElement('button', 'autoreview-btn autoreview-btn-secondary autoreview-regenerate', 'Regenerate');
  regenBtn.type = 'button';
  const copyBtn = createElement('button', 'autoreview-btn autoreview-btn-primary autoreview-copy', 'Copy Reply');
  copyBtn.type = 'button';

  header.append(title, closeBtn);
  toneRow.append(toneLabel, toneSelect);
  body.append(preview, toneRow, replyBox);
  footer.append(regenBtn, copyBtn);
  content.append(header, body, footer);
  modal.append(overlay, content);
  document.body.appendChild(modal);

  closeBtn.onclick = () => modal.remove();
  overlay.onclick = () => modal.remove();

  copyBtn.onclick = async () => {
    try {
      await navigator.clipboard.writeText(textArea.value);
      copyBtn.textContent = 'Copied!';
      setTimeout(() => {
        if (copyBtn) copyBtn.textContent = 'Copy Reply';
      }, 2000);
    } catch (err) {
      console.error('Copy failed:', err);
    }
  };

  regenBtn.onclick = async () => {
    const tone = toneSelect.value;
    regenBtn.textContent = 'Generating...';
    regenBtn.disabled = true;
    try {
      const newReply = await generateAIReply(review, tone);
      textArea.value = newReply;
    } catch (err) {
      alert(`AI Error: ${err.message}. Could not regenerate.`);
    } finally {
      regenBtn.textContent = 'Regenerate';
      regenBtn.disabled = false;
    }
  };
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getReviews') {
    const reviews = scrapeReviews();
    sendResponse({ reviews });
  }
  return true;
});

// Initialize with debounce
let timer;
function debouncedAddButtons() {
  clearTimeout(timer);
  timer = setTimeout(addAIReplyButtons, 500);
}

function init() {
  if (PLATFORM === 'unknown') {
    console.log('[AutoReview AI] Unknown platform, content script not initialized');
    return;
  }

  console.log(`[AutoReview AI] Detected platform: ${PLATFORM}`);

  // Add buttons on page load (wait for page to settle)
  setTimeout(addAIReplyButtons, 1500);

  // Re-check periodically for dynamically loaded content
  setInterval(addAIReplyButtons, 5000);

  // Watch for new reviews (infinite scroll)
  const observer = new MutationObserver((mutations) => {
    let shouldUpdate = false;
    for (const mutation of mutations) {
      if (mutation.addedNodes.length > 0) {
        shouldUpdate = true;
        break;
      }
    }
    if (shouldUpdate) debouncedAddButtons();
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
  });
}

// Run initialization
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
